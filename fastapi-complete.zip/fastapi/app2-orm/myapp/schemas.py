from pydantic import BaseModel



class Student(BaseModel):
    name: str
    sclass: str
    section: str