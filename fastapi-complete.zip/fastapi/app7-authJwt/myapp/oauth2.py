from jose import JWSError,jwt
from  datetime import datetime,timedelta

SECRET_KEY='090popouyb990089'
ALGORITHM= "HS256"
TOKEN_EXPIRY=30

def create_access_token(data: dict):
    to_encode= data.copy()

    expire=datetime.now() +timedelta(minutes=TOKEN_EXPIRY)
    to_encode.update({"exp" :expire})

    encoded_jwt =jwt.encode(to_encode,SECRET_KEY,algorithm=ALGORITHM)
    return encoded_jwt