from pydantic import BaseModel



class StudentBase(BaseModel):
    name: str
    sclass: str
    section: str


class StudentCreate(StudentBase):
    pass


class Stu(StudentBase):
    name: str
    class Config:
        orm_mode = True

class UserCreate(BaseModel):
    email: str
    password: str