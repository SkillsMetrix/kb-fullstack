from operator import index
from typing import Optional,List
from random import randrange
from fastapi import FastAPI, HTTPException, Response, Depends
from fastapi.params import Body
from sqlalchemy.orm import Session
from fastapi import status
import sqlite3
from . import models,schemas,utils
from .database import engine, get_db


models.Base.metadata.create_all(bind=engine)

app = FastAPI()



@app.get("/testconn")
def loadAll(db: Session = Depends(get_db)):
    return {"status": "success"}


@app.get("/loaddemo",response_model=List[schemas.Stu])
def loadAll(db: Session = Depends(get_db)):
    posts = db.query(models.Student).all()
    print(posts)
    return posts

@app.get("/loadall/{name}")
def loadByName(name:str, db: Session = Depends(get_db)):
    post=db.query(models.Student).filter(models.Student.name == name).first()
    print(post)
    return {"data" : post}

@app.delete("/deletepost/{name}")
def loadByName(name:str, db: Session = Depends(get_db)):
    post=db.query(models.Student).filter(models.Student.name == name)
    if post.first() ==None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Given ID not found")
    post.delete(synchronize_session=False)
    db.commit()
    return {"message":"user deleted"}
    

@app.post("/create",status_code=status.HTTP_201_CREATED,response_model=schemas.Stu)
def create_post(student:schemas.StudentCreate,db: Session=Depends(get_db)):
   
    new_post= models.Student(**student.dict())
    print(new_post)
    db.add(new_post)
    db.commit()
    db.refresh(new_post)
    return new_post





@app.put("/updatepost/{name}")
def update_post(name:str,newstudent:schemas.Stu,db: Session=Depends(get_db)):

    update_post= db.query(models.Stu).filter(models.Student.name == name)

    student=update_post.first()

    if student == None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Given ID not found")
    update_post.update(newstudent.dict(),synchronize_session=False)
    db.commit()
    return{"data":update_post.first()}



@app.post("/users",status_code=status.HTTP_201_CREATED,response_model=schemas.UserOut)
    
def create_user(user:schemas.UserCreate,db: Session=Depends(get_db)):
    hashed_password=utils.hash(user.password)
    user.password=hashed_password
    new_user= models.User(**user.dict())
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


@app.get("/users/{id}",response_model=schemas.UserOut)
def get_user(id:int, db: Session = Depends(get_db)):
    users = db.query(models.User).filter(models.User.id == id).first()
    if not users:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Given ID not found")
    return users