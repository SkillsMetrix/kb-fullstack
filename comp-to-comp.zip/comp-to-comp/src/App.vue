<template>
  <div id="app">
    <p></p>
   <UserApp></UserApp>
  </div>
</template>

<script>
import UserApp from './components/User.vue'
export default {
   
  components:{
    UserApp
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

 
</style>
