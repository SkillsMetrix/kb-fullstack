import { ref } from "vue";
import axios from "axios";

export default function useStudent() {
  const url = "http://localhost:3000/students/";
  const studentData = ref([]);
  //get students data

  const getAllStudents = async () => {
    try {
      const res = await axios(url);
      console.log(res.data);
      studentData.value = res.data;
    } catch (error) {
      console.log(error);
    }
  };
  // get single data
  const getSingleStudent = async (id) => {
    studentData.value = [];
    try {
      const res = await axios(url + id);
      console.log(res.data);
      studentData.value = res.data;
    } catch (error) {
      console.log(error);
    }
  };
  //create student
  const createStudent = async (formData) => {
    studentData.value = [];
    try {
      const config = {
        method: 'POST',
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: JSON.stringify(formData),
      };
      const res = await axios(config);
      studentData.value=res.data
    } catch (error) {}
  };

  const deleteStudent = async (id) => {
    studentData.value = [];
    try {
      const config = {
        method: 'DELETE',
        url: url +id,
        headers: {
          "Content-Type": "application/json",
        }
      };
      const res = await axios(config);
      studentData.value=res.data
    } catch (error) {}
  };
  const updateStudent = async (id,data) => {
    studentData.value = [];
    try {
      const config = {
        method: 'PUT',
        url: url +id,
        headers: {
          "Content-Type": "application/json",
          data: JSON.stringify(data)
        }
      };
      const res = await axios(config);
      studentData.value=res.data

     } catch (error) {}
  };
  return {
    studentData,
    getAllStudents,
    getSingleStudent,
    createStudent,
    deleteStudent,
    updateStudent
  };
}
