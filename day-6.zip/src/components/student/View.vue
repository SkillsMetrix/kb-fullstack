<template>
  <div class="shadow-md pb-6">
    <table class="table-auto w-full">
      <thead class="bg-slate-600 text-white">
        <tr>
          <th class="py-1">No</th>
          <th class="py-1">Name</th>
          <th class="py-1">Email</th>
        </tr>
      </thead>
      <tbody class="text-center">
        <tr>
          <td class="py-2">{{ studentData.id }}</td>
          <td class="py-2">{{ studentData.stuname }}</td>
          <td class="py-2">{{ studentData.email }}</td>
          <td class="py-2"></td>
        </tr>
      </tbody>
    </table>
    <div class="m-8 flex justify-center">
      <RouterLink :to="{ name: 'list' }">
        <button
          type="button"
          class="bg-emerald-700 font-medium py-2 rounded-md px-6"
        >
          Back To Home
        </button>
      </RouterLink>
    </div>
  </div>
</template>

<script setup>
import { RouterLink, useRoute } from "vue-router";
import useStudent from "../../composables/studentApi";
import { onMounted } from "vue";
const route = useRoute();
const { getSingleStudent, studentData } = useStudent();
onMounted(() => {
  getSingleStudent(route.params.id);
});
</script>

<style scoped></style>
