<script setup>
import { onMounted, reactive } from "vue";
import {RouterLink} from 'vue-router'
import {useRoute} from 'vue-router'
import useStudent from "../../composables/studentApi";
const {updateStudent,studentData,getSingleStudent} =useStudent()

const {params} = useRoute()
onMounted(()=>{
  getSingleStudent(params.id)
})
const formData = reactive({
  stuname: "",
  email: "",
});
const handleAddStudentForm = async () => {
     updateStudent(params.id,studentData.value)
};

</script>

<template>
  <div class="shadow-md pb-6">
    <div class="bg-indigo-600 p-4">
      <h3 class="text-3xl font-bold text-center">Edit Student</h3>
    </div>
    <form
      @submit.prevent="handleAddStudentForm"
      class="w-full"
      id="AddStudentForm">

      <div class="flex items-center m-6">
        <div class="w-1/5">
          <label for="stuname" class="font-medium">ID:</label>
        </div>
        <div class="w-4/5">
          <input
            type="text"
            id="stuid"
            class="border-2 border-gray-200 w-full py-2 px-4"
          readonly disabled
          v-model="studentData.id"
            
          />
        </div>
      </div>
      <div class="flex items-center m-6">
        <div class="w-1/5">
          <label for="stuname" class="font-medium">Name:</label>
        </div>
        <div class="w-4/5">
          <input
            type="text"
            id="stuname"
            class="border-2 border-gray-200 w-full py-2 px-4"
            v-model.trim="formData.stuname"
            placeholder="Enter StudentName"
            required
            v-model="studentData.stuname"
          />
        </div>
      </div>

      <div class="flex items-center m-6">
        <div class="w-1/5">
          <label for="email" class="font-medium">Email:</label>
        </div>
        <div class="w-4/5">
          <input
            type="email"
            id="email"
            class="border-2 border-gray-200 w-full py-2 px-4"
             v-model.trim="formData.email"
            placeholder="Enter Email"
            required
             v-model="studentData.email"
          />
        </div>
      </div>
      <div class="m-8 flex justify-center">
        <button class="bg-purple-700 font-medium py-2 rounded-md px-6">Edit</button>
      </div>

      <div class="m-8 flex justify-center">
        <RouterLink :to="{name:'list'}">
        <button
          type="button"
          class="bg-emerald-700 font-medium py-2 rounded-md px-6"
        >
          Back To Home
        </button>
    </RouterLink>
      </div>
    </form>
  </div>
</template>



<style scoped></style>
